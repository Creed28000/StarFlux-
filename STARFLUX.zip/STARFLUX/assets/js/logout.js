document.getElementById("logout-button").addEventListener("click", function() {
    localStorage.removeItem('userLoggedIn');
    window.location.href = "login.html"; // Redireciona para login após logout
});
